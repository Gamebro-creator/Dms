package com.dmms.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay

// ──────────────────────────────── Theme tokens ───────────────────────────────
private val BgDark      = Color(0xFF101214)
private val PanelDark   = Color(0xFF1D2025)
private val PanelBorder = Color(0xFF363B42)
private val AccentGreen = Color(0xFF1DB954)
private val DarkGreen   = Color(0xFF0E3D2E)
private val TextGray    = Color(0xFF9AA3AD)
private val KeyWhite    = Color(0xFFE8EAED)
private val KeyBlack    = Color(0xFF2A2E33)

// Rainbow lane colors per track index — shared by Song Editor lanes & Mixer strips.
private val TrackColors = listOf(
    Color(0xFF2ECC71), Color(0xFF3B82F6), Color(0xFF9B59B6),
    Color(0xFFEF5350), Color(0xFF14B8A6)
)

private fun trackColor(index: Int) = TrackColors[index % TrackColors.size]

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Full-screen immersive: hide status/navigation bars; swipe reveals them transiently.
        enableEdgeToEdge()
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())

        setContent { DmmsApp() }
    }
}

@Composable
fun DmmsApp() {
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var project by remember { mutableStateOf(LmmsProject(bpm = 140, tracks = emptyList())) }
    var selectedTab by rememberSaveable { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        delay(2500)
        showSplash = false
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize(), color = BgDark) {
            Crossfade(
                targetState = showSplash,
                animationSpec = tween(durationMillis = 1000),
                label = "splashCrossfade"
            ) { splash ->
                if (splash) SplashScreen() else StudioScreen(project, selectedTab,
                    onTabSelect = { selectedTab = it },
                    onLoad = { project = LmmsParser.loadTestProject() })
            }
        }
    }
}

// ─────────────────────────────────── Splash ──────────────────────────────────

@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.splash_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop   // fill any landscape aspect without distortion
        )
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.dmms_logo),
                contentDescription = "DMMS logo",
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(24.dp))
            )
            Spacer(Modifier.height(24.dp))
            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
            Spacer(Modifier.height(24.dp))
            Text(
                text = "Inspired by Linux MultiMedia Studio (LMMS)",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 14.sp
            )
        }
    }
}

// ───────────────────────────── Studio (landscape) ────────────────────────────

@Composable
fun StudioScreen(
    project: LmmsProject,
    selectedTab: Int,
    onTabSelect: (Int) -> Unit,
    onLoad: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(4.dp)) {
        TopBar(bpm = project.bpm, onLoad = onLoad)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxSize()) {
            Sidebar(selectedTab, onTabSelect, Modifier.width(96.dp).fillMaxHeight())
            Spacer(Modifier.width(4.dp))
            // 3-panel workspace: Song Editor 40% height on top;
            // bottom 60% split 65% Pattern Editor / 35% Mixer.
            Column(Modifier.fillMaxSize()) {
                SongEditorPanel(project, Modifier.fillMaxWidth().weight(0.40f))
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth().weight(0.60f)) {
                    PianoRoll(project, Modifier.weight(0.65f).fillMaxHeight())
                    Spacer(Modifier.width(4.dp))
                    MixerPanel(project, Modifier.weight(0.35f).fillMaxHeight())
                }
            }
        }
    }
}

// ─────────────────────────────────── Top bar ─────────────────────────────────

@Composable
fun TopBar(bpm: Int, onLoad: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(PanelDark, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Brand: mini logo + two-line title
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.dmms_logo),
                contentDescription = null,
                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
            )
            Spacer(Modifier.width(8.dp))
            Column {
                Text("DMMS Alpha", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Droid Music Maker Studio", color = TextGray, fontSize = 9.sp)
            }
        }

        // Transport: Play / Pause / Stop / Loop
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { /* future Oboe audio engine hook */ }) {
                Icon(Icons.Filled.PlayArrow, "Play", tint = AccentGreen, modifier = Modifier.size(30.dp))
            }
            // Pause/Stop have no icons in material-icons-core (deliberately kept
            // instead of the heavy icons-extended library) — drawn as shapes.
            IconButton(onClick = { }) { PauseGlyph() }
            IconButton(onClick = { }) { StopGlyph() }
            IconButton(onClick = { }) {
                Icon(Icons.Filled.Refresh, "Loop", tint = TextGray)
            }
        }

        // Project info tiles: BPM / time signature / clock
        InfoTile("$bpm", "BPM", AccentGreen)
        InfoTile("4", "4", TextGray)
        InfoTile("00:00:00", "MIN SEC MS", TextGray)

        // File ops: Save / Load(=Menu icon per spec) / Settings / overflow
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { }) {
                Icon(Icons.Filled.Save, "Save", tint = TextGray)
            }
            IconButton(onClick = onLoad) {   // ← Load: fills Piano Roll + BPM
                Icon(Icons.Filled.Menu, "Load test project", tint = TextGray)
            }
            IconButton(onClick = { }) {
                Icon(Icons.Filled.Settings, "Settings", tint = TextGray)
            }
            IconButton(onClick = { }) {
                Icon(Icons.Filled.MoreVert, "More options", tint = TextGray)
            }
        }
    }
}

/** Dark rounded value tile with a small caption. */
@Composable
fun InfoTile(value: String, caption: String, valueColor: Color) {
    Column(
        modifier = Modifier
            .background(Color(0xFF101214), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(caption, color = TextGray, fontSize = 8.sp)
    }
}

/** Two vertical bars — the universal pause glyph. */
@Composable
fun PauseGlyph(color: Color = TextGray) {
    Row(Modifier.size(22.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        repeat(2) { Box(Modifier.width(6.dp).height(18.dp).background(color, RoundedCornerShape(2.dp))) }
    }
}

/** Filled square — the universal stop glyph. */
@Composable
fun StopGlyph(color: Color = TextGray) {
    Box(Modifier.size(20.dp).background(color, RoundedCornerShape(3.dp)))
}

// ─────────────────────────────────── Sidebar ─────────────────────────────────

@Composable
fun Sidebar(selectedTab: Int, onTabSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf(
        Triple("Project", Icons.Filled.Home),
        Triple("My Samples", Icons.Filled.List),
        Triple("Instruments", Icons.Filled.PlayArrow),
        Triple("Automation", Icons.Filled.Refresh),
        Triple("FX Effects", Icons.Filled.Star),
        Triple("Tools", Icons.Filled.Build),
        Triple("Settings", Icons.Filled.Settings),
        Triple("About", Icons.Filled.Info)
    )
    Column(modifier.background(PanelDark, RoundedCornerShape(8.dp)).padding(6.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items.forEachIndexed { index, (label, icon) ->
                val selected = index == selectedTab
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (selected) DarkGreen else Color.Transparent, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, label, tint = if (selected) AccentGreen else TextGray,
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(label, color = if (selected) Color.White else TextGray, fontSize = 11.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Image(
            painter = painterResource(id = R.drawable.dmms_logo),
            contentDescription = null,
            modifier = Modifier.size(48.dp).align(Alignment.CenterHorizontally),
            alpha = 0.5f
        )
    }
}

// ──────────────────────────────── Song Editor ────────────────────────────────

@Composable
fun SongEditorPanel(project: LmmsProject, modifier: Modifier = Modifier) {
    Box(modifier.background(PanelDark, RoundedCornerShape(8.dp))) {
        Canvas(Modifier.fillMaxSize().padding(start = 8.dp, top = 26.dp, end = 8.dp, bottom = 6.dp)) {
            val bars = 8
            val lanes = project.tracks.size.coerceAtLeast(1)
            val laneH = size.height / lanes

            // Colored lane backgrounds, one per track (shared with Mixer colors)
            project.tracks.forEachIndexed { i, _ ->
                drawRect(
                    color = trackColor(i).copy(alpha = 0.22f),
                    topLeft = Offset(0f, i * laneH),
                    size = Size(size.width, laneH - 2f)
                )
            }
            // Bar grid: heavier line every 4th bar
            for (bar in 0..bars) {
                val x = size.width / bars * bar
                drawLine(if (bar % 4 == 0) TextGray else PanelBorder,
                    Offset(x, 0f), Offset(x, size.height),
                    strokeWidth = if (bar % 4 == 0) 2f else 1f)
            }
        }
        PanelLabel("Song Editor", Modifier.align(Alignment.TopStart).padding(8.dp))
        Column(Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 28.dp)) {
            project.tracks.forEachIndexed { i, track ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).background(trackColor(i), CircleShape))
                    Spacer(Modifier.width(4.dp))
                    Text(track.name, color = TextGray, fontSize = 10.sp)
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

// ─────────────────────────────────── Piano Roll ──────────────────────────────

@Composable
fun PianoRoll(project: LmmsProject, modifier: Modifier = Modifier) {
    // Only instrument tracks render here; beat tracks live in the
    // Beat+Bassline editor (future milestone).
    val notes = remember(project) {
        project.tracks.filter { it.type == "instrument" }.flatMap { it.notes }
    }
    val activeInstrument = project.tracks.firstOrNull { it.type == "instrument" }?.name ?: ""

    Box(modifier.background(PanelDark, RoundedCornerShape(8.dp))) {
        Canvas(Modifier.fillMaxSize().padding(top = 26.dp)) {
            val headerPad = 26.dp.toPx()
            val keyboardW = 48.dp.toPx()
            val gridW = size.width - keyboardW
            val gridH = size.height - headerPad

            val minKey = (notes.minOfOrNull { it.key } ?: 48) - 4
            val maxKey = (notes.maxOfOrNull { it.key } ?: 72) + 4
            val keyH = gridH / (maxKey - minKey + 1)

            val totalTicks = notes.maxOfOrNull { it.pos + it.len }
                ?.coerceAtLeast(LmmsProject.TICKS_PER_BAR * 4)
                ?: (LmmsProject.TICKS_PER_BAR * 4)

            // Grid: vertical beat lines (heavier on bars)
            var beat = 0
            while (beat * LmmsProject.TICKS_PER_BEAT <= totalTicks) {
                val x = keyboardW + (beat * LmmsProject.TICKS_PER_BEAT).toFloat() / totalTicks * gridW
                drawLine(if (beat % 4 == 0) TextGray else PanelBorder,
                    Offset(x, headerPad), Offset(x, size.height),
                    strokeWidth = if (beat % 4 == 0) 2f else 1f)
                beat++
            }
            for (k in minKey..maxKey) {
                val y = headerPad + (maxKey - k) * keyH
                drawLine(PanelBorder, Offset(keyboardW, y), Offset(size.width, y))
            }

            // Piano keyboard strip (white keys, then black overlays)
            for (k in minKey..maxKey) {
                val y = headerPad + (maxKey - k) * keyH
                drawRect(KeyWhite, topLeft = Offset(0f, y), size = Size(keyboardW, keyH))
            }
            val blackPc = setOf(1, 3, 6, 8, 10)   // C# D# F# G# A#
            for (k in minKey..maxKey) {
                if (k % 12 in blackPc) {
                    val y = headerPad + (maxKey - k) * keyH
                    drawRect(KeyBlack, topLeft = Offset(keyboardW * 0.45f, y),
                        size = Size(keyboardW * 0.55f, keyH))
                }
            }

            // Notes: LMMS pos → X, key → Y (LMMS green)
            for (n in notes) {
                val left = keyboardW + n.pos.toFloat() / totalTicks * gridW
                val w = (n.len.toFloat() / totalTicks * gridW).coerceAtLeast(4f)
                val top = headerPad + (maxKey - n.key) * keyH
                drawRoundRect(
                    color = AccentGreen,
                    topLeft = Offset(left + 1f, top + 1f),
                    size = Size(w - 2f, keyH - 2f),
                    cornerRadius = CornerRadius(4f, 4f)
                )
            }
        }
        PanelLabel("Pattern Editor" + if (activeInstrument.isNotEmpty()) " – $activeInstrument" else "",
            Modifier.align(Alignment.TopStart).padding(8.dp))
    }
}

// ───────────────────────────────────── Mixer ─────────────────────────────────

@Composable
fun MixerPanel(project: LmmsProject, modifier: Modifier = Modifier) {
    Box(modifier.background(PanelDark, RoundedCornerShape(8.dp))) {
        Row(
            Modifier.fillMaxSize().padding(top = 30.dp, start = 8.dp, end = 8.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MixerStrip("Master", AccentGreen, 0.7f)
            project.tracks.forEachIndexed { i, track ->
                MixerStrip(track.name, trackColor(i), 0.3f + 0.15f * (i % 3))
            }
        }
        PanelLabel("Mixer", Modifier.align(Alignment.TopStart).padding(8.dp))
    }
}

@Composable
fun MixerStrip(name: String, color: Color, level: Float) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(name, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier
                .background(color, RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp))
        Box(Modifier.size(14.dp).background(Color(0xFF3A3F46), CircleShape))  // knob
        Row(verticalAlignment = Alignment.Bottom) {
            // Level meter: green gradient fill
            Box(
                Modifier.width(6.dp).height(64.dp).background(Color(0xFF101214), RoundedCornerShape(3.dp))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(level)
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(listOf(AccentGreen, Color(0xFF66BB6A))),
                            RoundedCornerShape(3.dp)
                        )
                )
            }
            Spacer(Modifier.width(4.dp))
            Box(Modifier.width(10.dp).height(64.dp).background(Color(0xFF101214), RoundedCornerShape(5.dp))) {
                Box(Modifier.fillMaxWidth().height(18.dp).align(Alignment.Center).background(TextGray, RoundedCornerShape(3.dp)))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("M", color = TextGray, fontSize = 8.sp,
                modifier = Modifier.background(Color(0xFF2A2E33), RoundedCornerShape(3.dp)).padding(horizontal = 4.dp, vertical = 1.dp))
            Text("S", color = TextGray, fontSize = 8.sp,
                modifier = Modifier.background(Color(0xFF2A2E33), RoundedCornerShape(3.dp)).padding(horizontal = 4.dp, vertical = 1.dp))
        }
    }
}

@Composable
fun PanelLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Medium,
        modifier = modifier
            .background(Color(0xCC101214), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp))
}
