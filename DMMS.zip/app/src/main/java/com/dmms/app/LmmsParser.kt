package com.dmms.app

/**
 * LMMS project model + parser layer (Alpha version).
 *
 * LMMS stores projects as XML (.mmp) or gzipped XML (.mmpz). Relevant schema subset:
 *
 *   <song>
 *     <head><bpm>140</bpm></head>
 *     <trackcontainer>
 *       <track type="instrumentTrack" name="TripleOscillator">
 *         <pattern>
 *           <note pos="0" len="192" key="60" vel="100"/>
 *         </pattern>
 *       </track>
 *       <track type="beat+basslineTrack" name="Kicker">...</track>
 *     </trackcontainer>
 *   </song>
 *
 * Unit mapping (matches LMMS internals):
 *   - pos / len are in TICKS: 192 ticks per beat, 768 ticks per bar (4/4).
 *   - key is a raw MIDI note number (60 = middle C) — the LMMS "key" attribute.
 *   - vel is MIDI velocity 0..127.
 */
data class LmmsNote(
    val pos: Int,   // start position in ticks
    val len: Int,   // length in ticks
    val key: Int,   // MIDI note number, 60 = middle C
    val vel: Int    // velocity 0..127
)

data class LmmsTrack(
    val name: String,
    val instrument: String,       // "tripleoscillator", "kicker", ...
    val type: String,             // "instrument" or "beat" (mirrors LMMS track types)
    val notes: List<LmmsNote>
)

data class LmmsProject(
    val bpm: Int,
    val tracks: List<LmmsTrack>
) {
    companion object {
        const val TICKS_PER_BEAT = 192
        const val TICKS_PER_BAR = 768   // 4/4
    }
}

object LmmsParser {

    /**
     * Hardcoded Alpha "Test Project".
     *  - TripleOscillator: 4-bar melodic phrase in A minor.
     *  - Kicker: four-on-the-floor, one hit per beat.
     *  - Hi-Hat: offbeat eighth notes.
     * Produces the exact in-memory shape the real .mmp/.mmpz parser will produce later.
     */
    fun loadTestProject(): LmmsProject {
        val melody = listOf(
            LmmsNote(pos = 0,    len = 192, key = 57, vel = 100), // A3
            LmmsNote(pos = 192,  len = 192, key = 60, vel = 100), // C4
            LmmsNote(pos = 384,  len = 192, key = 64, vel = 100), // E4
            LmmsNote(pos = 576,  len = 192, key = 67, vel = 100), // G4
            LmmsNote(pos = 768,  len = 192, key = 69, vel = 110), // A4
            LmmsNote(pos = 960,  len = 192, key = 72, vel = 100), // C5
            LmmsNote(pos = 1152, len = 384, key = 76, vel = 115), // E5 half note
            LmmsNote(pos = 1536, len = 192, key = 74, vel = 105), // D5
            LmmsNote(pos = 1728, len = 192, key = 71, vel = 100), // B4
            LmmsNote(pos = 1920, len = 192, key = 67, vel = 100), // G4
            LmmsNote(pos = 2112, len = 192, key = 64, vel = 100), // E4
            LmmsNote(pos = 2304, len = 768, key = 57, vel = 120)  // A3 whole note
        )
        val kick = (0 until 16).map { beat ->
            LmmsNote(pos = beat * 192, len = 192, key = 36, vel = 127)
        }
        val hat = (0 until 16).map { beat ->
            LmmsNote(pos = beat * 192 + 96, len = 96, key = 42, vel = 90)
        }
        return LmmsProject(
            bpm = 140,
            tracks = listOf(
                LmmsTrack("TripleOscillator", "tripleoscillator", "instrument", melody),
                LmmsTrack("Kicker", "kicker", "beat", kick),
                LmmsTrack("Hi-Hat", "hihat", "beat", hat)
            )
        )
    }
}
