# DMMS — Droid Music Maker Studio (Alpha 0.4.0)

Mobile-first LMMS project sketchpad. Android 7.0+ (API 24 — runs on Android 8),
landscape only, full-screen immersive.

## Build (no local PC)
1. Push this folder to a GitHub repo (branch `main`).
2. GitHub Actions (`.github/workflows/build.yml`) compiles automatically.
3. Download the `dmms-alpha-v4` artifact → `app-debug.apk`.

## Install on Android 8
1. Copy the APK to the phone.
2. Tap it → allow "Install from unknown sources" for your file manager/browser.
3. Open DMMS — landscape studio with splash, top bar, sidebar, Song Editor,
   Pattern Editor (piano roll) and Mixer.

## Alpha features
- Splash: generated artwork, logo, spinner, LMMS attribution, 1s crossfade.
- TopBar: Play/Pause/Stop/Loop, BPM 140, 4/4, clock, Save/Load/Settings/menu.
- Sidebar: 8 tabs, dark-green selection, logo watermark.
- Song Editor: colored track lanes (green/blue/purple) + bar grid.
- Pattern Editor: canvas piano keyboard + grid; green LMMS notes (pos→X, key→Y).
- Mixer: Master + per-track colored strips, level meters, M/S chips.
- Menu icon = Load: injects the hardcoded LMMS test project
  (TripleOscillator melody + Kicker + Hi-Hat).

## License note
UI code original. Future synth ports from LMMS (GPL-2.0-or-later) will make
DMMS GPL-compatible once ported DSP lands.
